import numpy as np
import matplotlib.pyplot as plt

def plot_quadratic(a=1.0, b=0.0, c=0.0, x_min=-10.0, x_max=10.0):
    """
    Grafica una función cuadrática y = ax² + bx + c.
    
    Args:
        a (float): Coeficiente de x².
        b (float): Coeficiente de x.
        c (float): Término constante.
        x_min (float): Límite inferior del eje x.
        x_max (float): Límite superior del eje x.
    """
    x = np.linspace(x_min, x_max, 1000)
    y = a*x**2 + b*x + c

    # Cálculo opcional del vértice y raíces reales (si existen)
    xv = -b/(2*a) if a != 0 else np.nan
    yv = a*xv**2 + b*xv + c if a != 0 else np.nan
    disc = b**2 - 4*a*c
    roots = []
    if a != 0 and disc >= 0:
        r1 = (-b - np.sqrt(disc)) / (2*a)
        r2 = (-b + np.sqrt(disc)) / (2*a)
        roots = sorted([r1, r2])

    plt.figure(figsize=(7,5))
    plt.plot(x, y, linewidth=2, label=f'y = {a:.2f}x² + {b:.2f}x + {c:.2f}')
    plt.axhline(0, linewidth=1)
    plt.axvline(0, linewidth=1)

    # Marcar el vértice si tiene sentido
    if np.isfinite(xv) and x_min <= xv <= x_max:
        plt.scatter([xv], [yv], s=50, zorder=3, label=f'Vértice ({xv:.2f}, {yv:.2f})')

    # Marcar raíces reales si caen en el rango
    for r in roots:
        if x_min <= r <= x_max:
            plt.scatter([r], [0], s=40, zorder=3, marker='x', label=f'Raíz {r:.2f}')

    # Ajuste de límites y cuadrícula
    y_pad = max(1.0, 0.1*(np.nanmax(y)-np.nanmin(y)))
    plt.xlim(x_min, x_max)
    plt.ylim(np.nanmin(y)-y_pad, np.nanmax(y)+y_pad)
    plt.grid(True, alpha=0.3)
    plt.legend(loc='best')
    plt.title('Gráfica de y = ax² + bx + c')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.show()